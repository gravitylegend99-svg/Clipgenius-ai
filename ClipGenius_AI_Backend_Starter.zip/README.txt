CLIPGENIUS AI — BACKEND STARTER

WHAT THIS VERSION DOES
- Serves the ClipGenius AI homepage.
- Accepts video uploads up to 500 MB.
- Stores uploaded video metadata locally.
- Offers a basic time-range clip endpoint using FFmpeg.
- Exports clips in vertical 9:16 format.

IMPORTANT LIMITATIONS
- This is a development starter, not a production-ready public service.
- The clip endpoint trims a time range chosen by the user. It does NOT detect viral
  moments or provide AI highlight detection.
- Automatic speech recognition/captions, user accounts, cloud storage, and multi-user
  security have not yet been added.
- Files and metadata are stored on the server's local disk. Many hosting providers
  use temporary storage, so production deployment needs persistent object storage.
- Before making this public, add authentication, per-user file isolation, rate limits,
  malware scanning, storage quotas, and background job processing.

REQUIREMENTS
- Node.js 20 or newer
- FFmpeg installed and available in PATH (only needed for clip rendering)

RUN LOCALLY
1. Extract this ZIP.
2. Install Node.js from the official Node.js website.
3. Install FFmpeg from its official distribution for your operating system.
4. Open a terminal in this project folder.
5. Run: npm install
6. Run: npm start
7. Open: http://localhost:3000

TEST THE BACKEND
- GET /api/health
- Upload a video from the homepage.
- POST /api/videos/:id/clips with JSON:
  { "startSeconds": 5, "durationSeconds": 20 }

The upload endpoint expects multipart/form-data with the field name "video".

NEXT
Connect a transcription service for captions, then an AI highlight-ranking workflow.
